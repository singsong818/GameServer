TRUNCATE TABLE DJH_AccountsDB.Accounts_InFo;
TRUNCATE TABLE DJH_AccountsDB.Accounts_Treasure;
TRUNCATE TABLE DJH_AccountsDB.`Customer_Statement`;
TRUNCATE TABLE DJH_TreasureDB.User_Items;
TRUNCATE TABLE DJH_RecordDB.User_Logon_Record;
TRUNCATE TABLE DJH_RecordDB.User_Treasure_Record;
