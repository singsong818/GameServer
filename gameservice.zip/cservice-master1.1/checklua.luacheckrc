-- 定义全局变量
globals = {
    "my_global_var",
    "another_global_var"
}
 
-- 忽略某些警告
ignore = {
    "unused",
    "unused_args"
}